


// Template class: the node in the linked list
template <typename T1, typename T2>
class Node {


};

// Define the linked list class
template <typename T1, typename T2>
class LinkedList {



};

