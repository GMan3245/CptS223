


template <typename T1, typename T2>
class ArrayNode {


};


template <typename T1, typename T2>
class Array {


};

